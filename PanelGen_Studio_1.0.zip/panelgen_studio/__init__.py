bl_info = {
    'name': 'PanelGen Studio',
    'author': 'PanelGen Tools',
    'version': (1, 0, 0),
    'blender': (5, 1, 0),
    'location': 'View3D > Sidebar > PanelGen; Properties > Modifiers',
    'description': 'Procedural relief panels, stationary-base orbit, exact gaps, continuous foundations and assembly exports',
    'category': 'Object',
}
import bpy
import os
import sys
import importlib.util
_runtime = None

def _runtime_path():
    folder = os.path.dirname(os.path.abspath(__file__))
    packaged = os.path.join(folder, 'runtime.py')
    if os.path.basename(__file__) == '__init__.py' and os.path.isfile(packaged):
        return packaged
    return os.path.join(bpy.utils.user_resource('SCRIPTS', path='panelgen_studio_data'), 'runtime.py')

def register():
    global _runtime
    if _runtime is not None:
        _runtime.unregister()
    path = _runtime_path()
    if not os.path.isfile(path):
        raise RuntimeError('PanelGen runtime missing. Install the complete PanelGen_Studio ZIP, not only this loader.')
    name = '_panelgen_studio_runtime'
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.register()
    _runtime = module

def unregister():
    global _runtime
    if _runtime is not None:
        _runtime.unregister()
        _runtime = None

if __name__ == '__main__':
    register()
